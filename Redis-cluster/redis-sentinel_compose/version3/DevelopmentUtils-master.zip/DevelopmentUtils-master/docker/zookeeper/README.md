# DevelopmentUtils
下载后
此为搭建 zookeeper 伪集群的文件，下载后可直接使用 docker-compose up -d 运行

该文件配置的 zookeeper 端口为 2181 2182 2183，可自行修改端口