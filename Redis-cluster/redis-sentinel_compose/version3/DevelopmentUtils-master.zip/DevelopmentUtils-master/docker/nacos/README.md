# DevelopmentUtils
下载后
此为搭建 nacos 环境的 docker-compose 文件。文件来自官方教程 

上述文件中 

standalone 文件夹中存放的是单机版 nacos 环境搭建

- 其中 init.d 目录下存放的是客户端的配置文件
	
- prometheus 存放监控配置
	

cluster 待更新